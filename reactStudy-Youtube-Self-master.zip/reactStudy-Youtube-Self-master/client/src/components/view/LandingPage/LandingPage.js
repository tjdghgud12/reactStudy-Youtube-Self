import React from 'react'

function LandingPage() {
    return (
        <div>
            <h>Hello World!</h>
            <div style={{width:'100px', height:'100px', backgroundColor:'black'}}>
                test
            </div>
        </div>
    )
}

export default LandingPage
